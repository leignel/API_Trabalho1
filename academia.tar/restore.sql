--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE academia;
--
-- Name: academia; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE academia WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE academia OWNER TO postgres;

\connect academia

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: instrutor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instrutor (
    id_instrutor integer NOT NULL,
    rg integer,
    nome character varying(255)
);


ALTER TABLE public.instrutor OWNER TO postgres;

--
-- Name: instrutor_id_instrutor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instrutor_id_instrutor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instrutor_id_instrutor_seq OWNER TO postgres;

--
-- Name: instrutor_id_instrutor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instrutor_id_instrutor_seq OWNED BY public.instrutor.id_instrutor;


--
-- Name: telefone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telefone (
    id_instrutor integer,
    id_telefone integer NOT NULL,
    telefone integer
);


ALTER TABLE public.telefone OWNER TO postgres;

--
-- Name: telefone_id_telefone_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telefone_id_telefone_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telefone_id_telefone_seq OWNER TO postgres;

--
-- Name: telefone_id_telefone_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telefone_id_telefone_seq OWNED BY public.telefone.id_telefone;


--
-- Name: turma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.turma (
    id_instrutor integer,
    id_turma integer NOT NULL,
    dia_semana character varying(255),
    nome_disciplina character varying(255)
);


ALTER TABLE public.turma OWNER TO postgres;

--
-- Name: turma_id_turma_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.turma_id_turma_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.turma_id_turma_seq OWNER TO postgres;

--
-- Name: turma_id_turma_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.turma_id_turma_seq OWNED BY public.turma.id_turma;


--
-- Name: instrutor id_instrutor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor ALTER COLUMN id_instrutor SET DEFAULT nextval('public.instrutor_id_instrutor_seq'::regclass);


--
-- Name: telefone id_telefone; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone ALTER COLUMN id_telefone SET DEFAULT nextval('public.telefone_id_telefone_seq'::regclass);


--
-- Name: turma id_turma; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma ALTER COLUMN id_turma SET DEFAULT nextval('public.turma_id_turma_seq'::regclass);


--
-- Data for Name: instrutor; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3339.dat

--
-- Data for Name: telefone; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3341.dat

--
-- Data for Name: turma; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3343.dat

--
-- Name: instrutor_id_instrutor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instrutor_id_instrutor_seq', 11, true);


--
-- Name: telefone_id_telefone_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telefone_id_telefone_seq', 2, true);


--
-- Name: turma_id_turma_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.turma_id_turma_seq', 2, true);


--
-- Name: instrutor instrutor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor
    ADD CONSTRAINT instrutor_pkey PRIMARY KEY (id_instrutor);


--
-- Name: telefone telefone_id_instrutor_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT telefone_id_instrutor_key UNIQUE (id_instrutor);


--
-- Name: telefone telefone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT telefone_pkey PRIMARY KEY (id_telefone);


--
-- Name: turma turma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma
    ADD CONSTRAINT turma_pkey PRIMARY KEY (id_turma);


--
-- Name: telefone fk7uxr8hdckk84vpslw2s5npdct; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT fk7uxr8hdckk84vpslw2s5npdct FOREIGN KEY (id_instrutor) REFERENCES public.instrutor(id_instrutor);


--
-- Name: turma fk9e9uimmuwjeam3ibguo1kyhvb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma
    ADD CONSTRAINT fk9e9uimmuwjeam3ibguo1kyhvb FOREIGN KEY (id_instrutor) REFERENCES public.instrutor(id_instrutor);


--
-- PostgreSQL database dump complete
--

